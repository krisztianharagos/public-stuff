#!/bin/bash

# Create the directory structure
mkdir -p my-helm-chart/templates

# Create the Helm template file
cat << EOF > my-helm-chart/templates/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.application.name }}
  labels:
    app: {{ .Values.application.name }}
    role: {{ .Values.application.role }}
    release: {{ .Release.Name }}
spec:
  replicas: {{ .Values.replicaCount }}
  revisionHistoryLimit: {{ .Values.revisionHistoryLimit }}
  selector:
    matchLabels:
      app: {{ .Values.application.name }}
      role: {{ .Values.application.role }}
      release: {{ .Release.Name }}
  template:
    metadata:
      labels:
        app: {{ .Values.application.name }}
        role: {{ .Values.application.role }}
        release: {{ .Release.Name }}
    spec:
      containers:
      - name: {{ .Values.application.name }}
        image: {{ default "docker.io" .Values.image.registry }}/{{ .Values.image.name }}
        ports:
        - containerPort: {{ .Values.application.port }}
        livenessProbe:
          httpGet:
            path: {{ .Values.probes.liveness.path }}
            port: {{ .Values.application.port }}
          initialDelaySeconds: {{ .Values.probes.liveness.initialDelay }}
          timeoutSeconds: {{ .Values.probes.liveness.timeoutSeconds }}
          periodSeconds: {{ .Values.probes.liveness.periodSeconds }}
          failureThreshold: {{ .Values.probes.liveness.failureThreshold }}
        readinessProbe:
          httpGet:
            path: {{ .Values.probes.readiness.path }}
            port: {{ .Values.application.port }}
          initialDelaySeconds: {{ .Values.probes.readiness.initialDelay }}
          timeoutSeconds: {{ .Values.probes.readiness.timeoutSeconds }}
          periodSeconds: {{ .Values.probes.readiness.periodSeconds }}
          failureThreshold: {{ .Values.probes.readiness.failureThreshold }}
        resources:
          requests:
            memory: {{ .Values.resources.memory.request }}
            cpu: {{ .Values.resources.cpu.request }}
          limits:
            memory: {{ .Values.resources.memory.limit }}
            cpu: {{ .Values.resources.cpu.limit }}
        env:
        {{- range $key, $value := .Values.env }}
        - name: {{ $key }}
          value: {{ $value | quote }}
        {{- end }}
EOF

# Create the Helm values file
cat << EOF > my-helm-chart/values.yaml
application:
  name: my-app
  role: backend
  port: 8080
image:
  name: my-app:v1.0
  registry: myregistry.azurecr.io
replicaCount: 3
revisionHistoryLimit: 10
probes:
  liveness:
    path: /healthz
    initialDelay: 5
    timeoutSeconds: 5
    periodSeconds: 10
    failureThreshold: 3
  readiness:
    path: /ready
    initialDelay: 5
    timeoutSeconds: 5
    periodSeconds: 10
    failureThreshold: 3
resources:
  memory:
    request: 256Mi
    limit: 512Mi
  cpu:
    request: 100m
    limit: 500m
env:
  MY_VAR: 123
  MY_OTHER_VAR: some-value
EOF

cat << EOF > my-helm-chart/Chart.yaml
apiVersion: v2
name: my-app
description: A Helm chart for deploying my-app
type: application
version: 0.1.0
appVersion: "1.0"
EOF
