@Configuration
public class KafkaTopicConfiguration {

    @Value("${kafka.topics.sms}")
    private String smsTopic;

    @Value("${kafka.topics.mail}")
    private String mailTopic;

    @Bean
    public NewTopic smsTopic() {
        return new NewTopic(smsTopic, 1, (short) 1);
    }

    @Bean
    public NewTopic mailTopic() {
        return new NewTopic(mailTopic, 2, (short) 1);
    }
}


@Configuration
public class KafkaProducerConfiguration {

    @Bean
    public ProducerFactory<String, Notification> producerFactory(
            @Value("${spring.kafka.bootstrap-servers}") String bootstrapServers) {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    public KafkaTemplate<String, Notification> kafkaTemplate(ProducerFactory<String, Notification> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }
}


@Service
public class NotificationProducer {

    private final KafkaTemplate<String, Notification> kafkaTemplate;

    @Value("${kafka.topics.sms}")
    private String smsTopic;

    @Value("${kafka.topics.mail}")
    private String mailTopic;

    public NotificationProducer(KafkaTemplate<String, Notification> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendSms(Notification notification) {
        kafkaTemplate.send(smsTopic, notification);
    }

    public void sendMail(Notification notification) {
        kafkaTemplate.send(mailTopic, notification);
    }
}

@Configuration
public class KafkaConsumerConfiguration {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Bean
    public ConsumerFactory<String, Notification> consumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "notification-consumers");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new JsonDeserializer<>(Notification.class));
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Notification> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Notification> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }
}


@Service
@KafkaListener(topics = {"${kafka.topics.sms}", "${kafka.topics.mail}"}, groupId = "${kafka.groups.one}", id = "persistence")
public class PersistenceNotificationConsumer {

    private final PersistenceRepository persistenceRepository;
    private final Clock clock;

    public PersistenceNotificationConsumer(PersistenceRepository persistenceRepository, Clock clock) {
        this.persistenceRepository = persistenceRepository;
        this.clock = clock;
    }

    @KafkaHandler
    public void consume(Notification notification, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        NotificationEntity entity = NotificationEntity.builder()
                .receiveDate(clock.now())
                .notificationType(getNotificationType(topic))
                .author(notification.author())
                .title(notification.title())
                .payload(notification.payload())
                .build();
        persistenceRepository.save(entity);
    }

    private NotificationType getNotificationType(String topic) {
        if (topic.equals("${kafka.topics.sms}")) {
            return NotificationType.SMS;
        } else if (topic.equals("${kafka.topics.mail}")) {
            return NotificationType.MAIL;
        } else {
            throw new IllegalArgumentException("Unknown topic: " + topic);
        }
    }
}


@Service
@KafkaListener(topics = "${kafka.topics.sms}", groupId = "${kafka.groups.two}", id = "sms")
public class SmsNotificationConsumer {

    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public SmsNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }

    @KafkaHandler
    public void consume(Notification notification) {
        communicatorsFacade.sms(clock.now(), notification.payload());
    }
}


@Service
@KafkaListener(topics = "${kafka.topics.mail}", groupId = "${kafka.groups.three}", id = "codility-mailbox", containerFactory = "kafkaListenerContainerFactory", topicPartitions = {
        @TopicPartition(topic = "${kafka.topics.mail}", partitions = { "0" })
})
public class CodilityMailboxNotificationConsumer {

    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public CodilityMailboxNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }

    @KafkaHandler
    public void consume(Notification notification) {
        communicatorsFacade.mail(clock.now(), notification.payload(), MailboxType.CODILITY);
    }
}


@Service
@KafkaListener(topics = "${kafka.topics.mail}", groupId = "${kafka.groups.three}", id = "outlook", containerFactory = "kafkaListenerContainerFactory", topicPartitions = {
        @TopicPartition(topic = "${kafka.topics.mail}", partitions = { "1" })
})
public class OutlookNotificationConsumer {

    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public OutlookNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }

    @KafkaHandler
    public void consume(Notification notification) {
        communicatorsFacade.mail(clock.now(), notification.payload(), MailboxType.OUTLOOK);
    }
}


public class CommunicatorsFacade {
    private final MailSender mailSender;

    public CommunicatorsFacade(MailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void mail(LocalDateTime date, String payload, MailboxType mailboxType) {
        MailMessage message = new MailMessage();
        message.setDate(date);
        message.setPayload(payload);
        message.setMailboxType(mailboxType);

        mailSender.sendMail(message);
    }

    // Other communication-related methods, e.g., sms(), push(), etc.
}