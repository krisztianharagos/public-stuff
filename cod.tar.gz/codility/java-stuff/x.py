import os

KAFKA_TOPIC_CONFIGURATION = """
package com.example.demo;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaTopicConfiguration {{
    @Value("${{kafka.topics.sms}}")
    private String smsTopic;

    @Value("${{kafka.topics.mail}}")
    private String mailTopic;

    @Bean
    public NewTopic smsTopic() {{
        return new NewTopic(smsTopic, 1, (short) 1);
    }}

    @Bean
    public NewTopic mailTopic() {{
        return new NewTopic(mailTopic, 2, (short) 1);
    }}
}}
"""

KAFKA_PRODUCER_CONFIGURATION = """
package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

@Configuration
public class KafkaProducerConfiguration {{
    @Bean
    public ProducerFactory<String, Notification> producerFactory(
            @Value("${{spring.kafka.bootstrap-servers}}") String bootstrapServers) {{
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }}

    @Bean
    public KafkaTemplate<String, Notification> kafkaTemplate(ProducerFactory<String, Notification> producerFactory) {{
        return new KafkaTemplate<>(producerFactory);
    }}
}}
"""

NOTIFICATION_PRODUCER = """
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class NotificationProducer {{
    private final KafkaTemplate<String, Notification> kafkaTemplate;

    @Value("${{kafka.topics.sms}}")
    private String smsTopic;

    @Value("${{kafka.topics.mail}}")
    private String mailTopic;

    public NotificationProducer(KafkaTemplate<String, Notification> kafkaTemplate) {{
        this.kafkaTemplate = kafkaTemplate;
    }}

    public void sendSms(Notification notification) {{
        kafkaTemplate.send(smsTopic, notification);
    }}

    public void sendMail(Notification notification) {{
        kafkaTemplate.send(mailTopic, notification);
    }}
}}
"""

KAFKA_CONSUMER_CONFIGURATION = """
package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

@Configuration
public class KafkaConsumerConfiguration {{
    @Value("${{spring.kafka.bootstrap-servers}}")
    private String bootstrapServers;

    @Bean
    public ConsumerFactory<String, Notification> consumerFactory() {{
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "notification-consumers");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new JsonDeserializer<>(Notification.class));
    }}

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Notification> kafkaListenerContainerFactory() {{
        ConcurrentKafkaListenerContainerFactory<String, Notification> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }}
}}
"""

PERSISTENCE_NOTIFICATION_CONSUMER = """
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

@Service
@KafkaListener(topics = {"${{kafka.topics.sms}}", "${{kafka.topics.mail}}"}, groupId = "${{kafka.groups.one}}", id = "persistence")
public class PersistenceNotificationConsumer {{
    private final PersistenceRepository persistenceRepository;
    private final Clock clock;

    public PersistenceNotificationConsumer(PersistenceRepository persistenceRepository, Clock clock) {{
        this.persistenceRepository = persistenceRepository;
        this.clock = clock;
    }}

    @KafkaHandler
    public void consume(Notification notification, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {{
        NotificationEntity entity = NotificationEntity.builder()
                .receiveDate(clock.now())
                .notificationType(getNotificationType(topic))
                .author(notification.author())
                .title(notification.title())
                .payload(notification.payload())
                .build();
        persistenceRepository.save(entity);
    }}

    private NotificationType getNotificationType(String topic) {{
        if (topic.equals("${{kafka.topics.sms}}")) {{
            return NotificationType.SMS;
        }} else if (topic.equals("${{kafka.topics.mail}}")) {{
            return NotificationType.MAIL;
        }} else {{
            throw new IllegalArgumentException("Unknown topic: " + topic);
        }}
    }}
}}
"""

SMS_NOTIFICATION_CONSUMER = """
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@KafkaListener(topics = "${{kafka.topics.sms}}", groupId = "${{kafka.groups.two}}", id = "sms")
public class SmsNotificationConsumer {{
    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public SmsNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {{
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }}

    @KafkaHandler
    public void consume(Notification notification) {{
        communicatorsFacade.sms(clock.now(), notification.payload());
    }}
}}
"""

CODILITY_MAILBOX_NOTIFICATION_CONSUMER = """
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.stereotype.Service;

@Service
@KafkaListener(topics = "${{kafka.topics.mail}}", groupId = "${{kafka.groups.three}}", id = "codility-mailbox", containerFactory = "kafkaListenerContainerFactory", topicPartitions = {{
        @TopicPartition(topic = "${{kafka.topics.mail}}", partitions = {{ "0" }}
)}}
)
public class CodilityMailboxNotificationConsumer {{
    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public CodilityMailboxNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {{
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }}

    @KafkaHandler
    public void consume(Notification notification) {{
        communicatorsFacade.mail(clock.now(), notification.payload(), MailboxType.CODILITY);
    }}
}}
"""

OUTLOOK_NOTIFICATION_CONSUMER = """
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.stereotype.Service;

@Service
@KafkaListener(topics = "${{kafka.topics.mail}}", groupId = "${{kafka.groups.three}}", id = "outlook", containerFactory = "kafkaListenerContainerFactory", topicPartitions = {{
        @TopicPartition(topic = "${{kafka.topics.mail}}", partitions = {{ "1" }}
)}}
)
public class OutlookNotificationConsumer {{
    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public OutlookNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {{
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }}

    @KafkaHandler
    public void consume(Notification notification) {{
        communicatorsFacade.mail(clock.now(), notification.payload(), MailboxType.OUTLOOK);
    }}
}}
"""

POM_XML = """
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.7.0</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>demo</name>
    <description>Demo project for Spring Boot</description>
    <properties>
        <java.version>11</java.version>
    </properties>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.kafka</groupId>
            <artifactId>spring-kafka</artifactId>
        </dependency>
        <dependency>
            <groupId>com.fasterxml.jackson.core</groupId>
            <artifactId>jackson-databind</artifactId>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.springframework.kafka</groupId>
            <artifactId>spring-kafka-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <excludes>
                        <exclude>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                        </exclude>
                    </excludes>
                </configuration>
            </plugin>
        </plugins>
    </build>

</project>
"""

def generate_files_and_folders():
    # Create the necessary folders
    os.makedirs("src/main/java/com/example/demo", exist_ok=True)

    # Generate the Java files
    files = [
        ("KafkaTopicConfiguration.java", KAFKA_TOPIC_CONFIGURATION),
        ("KafkaProducerConfiguration.java", KAFKA_PRODUCER_CONFIGURATION),
        ("NotificationProducer.java", NOTIFICATION_PRODUCER),
        ("KafkaConsumerConfiguration.java", KAFKA_CONSUMER_CONFIGURATION),
        ("PersistenceNotificationConsumer.java", PERSISTENCE_NOTIFICATION_CONSUMER),
        ("SmsNotificationConsumer.java", SMS_NOTIFICATION_CONSUMER),
        ("CodilityMailboxNotificationConsumer.java", CODILITY_MAILBOX_NOTIFICATION_CONSUMER),
        ("OutlookNotificationConsumer.java", OUTLOOK_NOTIFICATION_CONSUMER),
    ]

    for filename, content in files:
        with open(f"src/main/java/com/example/demo/{filename}", "w") as f:
            f.write(content)

    # Generate the pom.xml file
    with open("pom.xml", "w") as f:
        f.write(POM_XML)

    print("Files and folders generated successfully!")

if __name__ == "__main__":
    generate_files_and_folders()