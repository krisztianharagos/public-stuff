
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;

@Service
@KafkaListener(topics = {"${{kafka.topics.sms}}", "${{kafka.topics.mail}}"}, groupId = "${{kafka.groups.one}}", id = "persistence")
public class PersistenceNotificationConsumer {{
    private final PersistenceRepository persistenceRepository;
    private final Clock clock;

    public PersistenceNotificationConsumer(PersistenceRepository persistenceRepository, Clock clock) {{
        this.persistenceRepository = persistenceRepository;
        this.clock = clock;
    }}

    @KafkaHandler
    public void consume(Notification notification, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {{
        NotificationEntity entity = NotificationEntity.builder()
                .receiveDate(clock.now())
                .notificationType(getNotificationType(topic))
                .author(notification.author())
                .title(notification.title())
                .payload(notification.payload())
                .build();
        persistenceRepository.save(entity);
    }}

    private NotificationType getNotificationType(String topic) {{
        if (topic.equals("${{kafka.topics.sms}}")) {{
            return NotificationType.SMS;
        }} else if (topic.equals("${{kafka.topics.mail}}")) {{
            return NotificationType.MAIL;
        }} else {{
            throw new IllegalArgumentException("Unknown topic: " + topic);
        }}
    }}
}}
