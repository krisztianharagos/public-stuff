
package com.example.demo;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KafkaTopicConfiguration {{
    @Value("${{kafka.topics.sms}}")
    private String smsTopic;

    @Value("${{kafka.topics.mail}}")
    private String mailTopic;

    @Bean
    public NewTopic smsTopic() {{
        return new NewTopic(smsTopic, 1, (short) 1);
    }}

    @Bean
    public NewTopic mailTopic() {{
        return new NewTopic(mailTopic, 2, (short) 1);
    }}
}}
