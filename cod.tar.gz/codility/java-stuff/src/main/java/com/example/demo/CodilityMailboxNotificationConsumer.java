
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.stereotype.Service;

@Service
@KafkaListener(topics = "${{kafka.topics.mail}}", groupId = "${{kafka.groups.three}}", id = "codility-mailbox", containerFactory = "kafkaListenerContainerFactory", topicPartitions = {{
        @TopicPartition(topic = "${{kafka.topics.mail}}", partitions = {{ "0" }}
)}}
)
public class CodilityMailboxNotificationConsumer {{
    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public CodilityMailboxNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {{
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }}

    @KafkaHandler
    public void consume(Notification notification) {{
        communicatorsFacade.mail(clock.now(), notification.payload(), MailboxType.CODILITY);
    }}
}}
