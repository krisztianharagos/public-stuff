
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
@KafkaListener(topics = "${{kafka.topics.sms}}", groupId = "${{kafka.groups.two}}", id = "sms")
public class SmsNotificationConsumer {{
    private final CommunicatorsFacade communicatorsFacade;
    private final Clock clock;

    public SmsNotificationConsumer(CommunicatorsFacade communicatorsFacade, Clock clock) {{
        this.communicatorsFacade = communicatorsFacade;
        this.clock = clock;
    }}

    @KafkaHandler
    public void consume(Notification notification) {{
        communicatorsFacade.sms(clock.now(), notification.payload());
    }}
}}
