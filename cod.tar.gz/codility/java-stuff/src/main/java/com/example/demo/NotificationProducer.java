
package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class NotificationProducer {{
    private final KafkaTemplate<String, Notification> kafkaTemplate;

    @Value("${{kafka.topics.sms}}")
    private String smsTopic;

    @Value("${{kafka.topics.mail}}")
    private String mailTopic;

    public NotificationProducer(KafkaTemplate<String, Notification> kafkaTemplate) {{
        this.kafkaTemplate = kafkaTemplate;
    }}

    public void sendSms(Notification notification) {{
        kafkaTemplate.send(smsTopic, notification);
    }}

    public void sendMail(Notification notification) {{
        kafkaTemplate.send(mailTopic, notification);
    }}
}}
